# AnTrack Logo Kit

Files:
- antrack-mark.svg / .png — standalone A mark, transparent
- antrack-logo-light.svg — horizontal wordmark for light UI
- antrack-logo-dark.svg — horizontal wordmark for dark UI
- antrack-app-icon-light.png — 1024x1024 app icon
- antrack-app-icon-dark.png — 1024x1024 app icon
- favicon-32.png / 64.png / 128.png — favicon sizes

Recommended:
- Use SVG for the web header/logo whenever possible.
- Use the PNG app icons for PWA/mobile store assets.
- Keep the same safe area around the A mark.
- The mark uses olive + terracotta to match the warm AnTrack UI.
